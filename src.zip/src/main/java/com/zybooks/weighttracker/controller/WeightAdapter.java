package com.zybooks.weighttracker.controller;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.zybooks.weighttracker.R;
import com.zybooks.weighttracker.model.WeightEntry;

import java.util.List;

public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.WeightViewHolder> {
    private final List<WeightEntry> weightEntryList;

    public WeightAdapter(List<WeightEntry> weightEntryList) {
        this.weightEntryList = weightEntryList;
    }

    @NonNull
    @Override
    public WeightViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.weight_item, parent, false);
        return new WeightViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(WeightViewHolder holder, int position) {
        WeightEntry entry = weightEntryList.get(position);
        holder.weightTextView.setText(String.format("%s kg", entry.getWeight()));  // Formatting the weight
        holder.dateTextView.setText(entry.getDate());  // Displaying the date
    }

    @Override
    public int getItemCount() {
        return weightEntryList.size();
    }

    public static class WeightViewHolder extends RecyclerView.ViewHolder {
        public TextView weightTextView;
        public TextView dateTextView;

        public WeightViewHolder(View view) {
            super(view);
            weightTextView = view.findViewById(R.id.weightView);
            dateTextView = view.findViewById(R.id.dateView);
        }
    }
}