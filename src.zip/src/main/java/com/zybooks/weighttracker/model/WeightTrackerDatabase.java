package com.zybooks.weighttracker.model;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

public class WeightTrackerDatabase extends SQLiteOpenHelper {

    private static WeightTrackerDatabase instance;

    private static final String DATABASE_NAME = "WeightTracker.db";
    private static final int DATABASE_VERSION = 1;

    // Table names
    private static final String TABLE_PROFILES = "user_profiles";
    private static final String TABLE_WEIGHTS = "weights";

    // Common column names
    private static final String COLUMN_USER_ID = "user_id";
    private static final String COLUMN_NAME = "name";
    private static final String COLUMN_DATE = "date";
    private static final String COLUMN_TARGET_DATE = "target_date";

    // Specific column names
    private static final String COLUMN_USER_NAME = "username";
    private static final String COLUMN_USER_PASSWORD = "password";
    private static final String COLUMN_GOAL_WEIGHT = "goal_weight";
    private static final String COLUMN_WEIGHT_ID = "weight_id";
    private static final String COLUMN_WEIGHT = "weight";

    // SQL to create tables
    private static final String SQL_CREATE_PROFILES_TABLE =
            "CREATE TABLE user_profiles (" +
                    COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_USER_NAME + " TEXT, " +
                    COLUMN_USER_PASSWORD + " TEXT, " +
                    COLUMN_NAME + " TEXT, " +
                    COLUMN_GOAL_WEIGHT + " REAL, " +
                    COLUMN_TARGET_DATE + " TEXT)";
    private static final String SQL_CREATE_WEIGHTS_TABLE =
            "CREATE TABLE " + TABLE_WEIGHTS + " (" +
                    COLUMN_WEIGHT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_USER_ID + " INTEGER, " +
                    COLUMN_WEIGHT + " REAL, " +
                    COLUMN_DATE + " TEXT, " +
                    "FOREIGN KEY(" + COLUMN_USER_ID + ") REFERENCES " + TABLE_PROFILES + "(" + COLUMN_USER_ID + "))";

    // SQL to delete tables

    private static final String SQL_DELETE_PROFILES_TABLE =
            "DROP TABLE IF EXISTS " + TABLE_PROFILES;

    private static final String SQL_DELETE_WEIGHTS_TABLE =
            "DROP TABLE IF EXISTS " + TABLE_WEIGHTS;

    public static synchronized WeightTrackerDatabase getInstance(Context context) {
        if (instance == null) {
            instance = new WeightTrackerDatabase(context.getApplicationContext());
        }
        return instance;
    }

    public WeightTrackerDatabase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        Log.d("Database", "Database constructor called");
    }

    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        try {
            Log.d("Database", "onCreate called");
            db.execSQL(SQL_CREATE_PROFILES_TABLE);
            db.execSQL(SQL_CREATE_WEIGHTS_TABLE);
        } catch (Exception e) {
            Log.e("Database", "Error creating tables", e);
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(SQL_DELETE_PROFILES_TABLE);
        db.execSQL(SQL_DELETE_WEIGHTS_TABLE);
        onCreate(db);
    }

    // Method to validate user login
    public boolean validateUser(String username, String hashedPassword) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_PROFILES + " WHERE "
                + COLUMN_USER_NAME + " = ? AND " + COLUMN_USER_PASSWORD + " = ?";

        try (Cursor cursor = db.rawQuery(query, new String[]{username, hashedPassword})) {

            return cursor.moveToFirst();
        }
    }

    // Method to add user profile
    public boolean addUserProfile(String username, String password, String name, double goalWeight, String targetDate) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_NAME, username);
        values.put(COLUMN_USER_PASSWORD, hashPassword(password)); // Hash the password here
        values.put(COLUMN_NAME, name);
        values.put(COLUMN_GOAL_WEIGHT, goalWeight);
        values.put(COLUMN_TARGET_DATE, targetDate);

        long result = db.insert(TABLE_PROFILES, null, values);
        db.close();
        return result != -1;
    }

    private String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(password.getBytes());
            return Base64.getEncoder().encodeToString(hash);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Failed to hash password", e);
        }
    }

    // Method to retrieve a user's ID by username
    public int getUserId(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT " + COLUMN_USER_ID + " FROM " + TABLE_PROFILES + " WHERE " + COLUMN_USER_NAME + " = ?";
        try {
            @SuppressLint("Recycle") Cursor cursor = db.rawQuery(query, new String[]{username});
            if (cursor.moveToFirst()) {
                return cursor.getInt(0);
            } else {
                return -1;  // User not found
            }
        } catch (Exception e) {
            Log.e("Database", "Error getting user ID", e);
            return -1;
        }
    }




    // Method to add weight entry
    public void addWeight(WeightEntry weightEntry) {
        ContentValues values = new ContentValues();
        values.put(COLUMN_WEIGHT, weightEntry.getWeight());
        values.put(COLUMN_DATE, weightEntry.getDate());

        try (SQLiteDatabase db = this.getWritableDatabase()) {
            long newRowId = db.insert(TABLE_WEIGHTS, null, values);
            if (newRowId == -1) {
                Log.e("Database", "Failed to add weight entry");
            } else {
                Log.i("Database", "Weight entry added with ID: " + newRowId);
            }
        }
    }

    public Cursor fetchUserProfile(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_PROFILES + " WHERE " + COLUMN_USER_ID + " = ?";
        return db.rawQuery(query, new String[]{String.valueOf(userId)});
    }

    // Method to get all weight entries
    public List<WeightEntry> getAllWeights() {
        List<WeightEntry> weightList = new ArrayList<>();
        String query;
        query = "SELECT " + COLUMN_WEIGHT_ID + ", " + COLUMN_WEIGHT + ", " + COLUMN_DATE + " FROM " + TABLE_WEIGHTS;
        try (SQLiteDatabase db = this.getReadableDatabase();
             Cursor cursor = db.query(TABLE_WEIGHTS, null, null, null, null, null, null)) {
            if (cursor.moveToFirst()) {
                do {
                    @SuppressLint("Range") double weight = cursor.getDouble(cursor.getColumnIndex(COLUMN_WEIGHT));
                    @SuppressLint("Range") String date = cursor.getString(cursor.getColumnIndex(COLUMN_DATE));
                    weightList.add(new WeightEntry(weight, date));
                } while (cursor.moveToNext());
            }
        }
        return weightList;
    }
}

    // Unused methods. Storing because I couldn't part with them.

    // Get all user profiles for validation purposes
//    public List<String> getAllUserProfiles() {
//        List<String> userProfiles = new ArrayList<>();
//        SQLiteDatabase db = this.getReadableDatabase();
//        String query = "SELECT * FROM " + TABLE_PROFILES;
//        Cursor cursor = db.rawQuery(query, null);
//
//        while (cursor.moveToNext()) {
//            @SuppressLint("Range") int userId = cursor.getInt(cursor.getColumnIndex(COLUMN_USER_ID));
//            @SuppressLint("Range") String username = cursor.getString(cursor.getColumnIndex(COLUMN_USER_NAME));
//            @SuppressLint("Range") String password = cursor.getString(cursor.getColumnIndex(COLUMN_USER_PASSWORD));
//            @SuppressLint("Range") String name = cursor.getString(cursor.getColumnIndex(COLUMN_NAME));
//            @SuppressLint("Range") float goalWeight = cursor.getFloat(cursor.getColumnIndex(COLUMN_GOAL_WEIGHT));
//            @SuppressLint("Range") String targetDate = cursor.getString(cursor.getColumnIndex(COLUMN_TARGET_DATE));
//
//            String userProfile = userId + ";" + username + ";" + password + ";" + name + ";" + goalWeight + ";" + targetDate;
//            userProfiles.add(userProfile);
//        }
//
//        cursor.close();
//        return userProfiles;
//    }




//    public boolean updateUserProfile(int userId, String name, double goalWeight, String targetDate) {
//        SQLiteDatabase db = this.getWritableDatabase();
//        ContentValues values = new ContentValues();
//        values.put(COLUMN_NAME, name);
//        values.put(COLUMN_GOAL_WEIGHT, goalWeight);
//        values.put(COLUMN_TARGET_DATE, targetDate);
//
//        int result = db.update(TABLE_PROFILES, values, COLUMN_USER_ID + " = ?", new String[]{String.valueOf(userId)});
//        db.close();
//        return result > 0;
//    }
//
//    public void deleteUser(int userId) {
//        SQLiteDatabase db = this.getWritableDatabase();
//        db.delete(TABLE_PROFILES, COLUMN_USER_ID + " = ?", new String[]{String.valueOf(userId)});
//        db.delete(TABLE_WEIGHTS, COLUMN_USER_ID + " = ?", new String[]{String.valueOf(userId)});
//        db.delete(TABLE_USERS, COLUMN_USER_ID + " = ?", new String[]{String.valueOf(userId)});
//        db.close();
//    }