package com.zybooks.weighttracker.model;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.zybooks.weighttracker.view.AddWeight;
import com.zybooks.weighttracker.R;
import com.zybooks.weighttracker.view.SetGoal;
import com.zybooks.weighttracker.controller.WeightAdapter;

import java.util.List;

public class WeightList extends AppCompatActivity {
    private RecyclerView recyclerView;
    private WeightAdapter adapter;
    private WeightTrackerDatabase dbHelper;
    private Button addWeightButton;
    private Button setGoalButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.weight_list);

        recyclerView = findViewById(R.id.weight_list_recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        dbHelper = new WeightTrackerDatabase(this);
        loadWeights();

        addWeightButton = findViewById(R.id.add_weight_button);
        setGoalButton = findViewById(R.id.set_goal_button);

        addWeightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Intent to open another activity to add a new weight
                startActivity(new Intent(WeightList.this, AddWeight.class));
            }
        });

        setGoalButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Intent to open another activity to set a goal weight
                startActivity(new Intent(WeightList.this, SetGoal.class)); // Ensure you have a SetGoalActivity
            }
        });
    }

    private void loadWeights() {
        List<WeightEntry> weights = dbHelper.getAllWeights();
        if (weights != null && !weights.isEmpty()) {
            adapter = new WeightAdapter(weights);
            recyclerView.setAdapter(adapter);
        } else {
            Toast.makeText(this, "No weight data available.", Toast.LENGTH_LONG).show();
        }
    }
}