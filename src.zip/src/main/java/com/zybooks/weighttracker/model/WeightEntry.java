package com.zybooks.weighttracker.model;

public class WeightEntry {
    private int id;
    private double weight;
    private String date;

    // Constructor for new weight entries where ID is not known yet
    public WeightEntry(double weight, String date) {
        this.id = 0; // Default to 0 or set to -1 to indicate not set
        this.weight = weight;
        this.date = date;
    }

    // Getters and setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}