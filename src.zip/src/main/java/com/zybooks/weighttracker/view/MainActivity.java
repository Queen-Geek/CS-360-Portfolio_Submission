package com.zybooks.weighttracker.view;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.zybooks.weighttracker.R;
import com.zybooks.weighttracker.model.WeightTrackerDatabase;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

public class MainActivity extends AppCompatActivity {

    private EditText usernameEditText, passwordEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        usernameEditText = findViewById(R.id.username_field);
        passwordEditText = findViewById(R.id.password_field);
        Button loginButton = findViewById(R.id.login_button);
        Button createAccountButton = findViewById(R.id.create_account_button);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = usernameEditText.getText().toString().trim();
                String password = passwordEditText.getText().toString().trim();
                int userId = WeightTrackerDatabase.getInstance(MainActivity.this).getUserId(username);
                Intent loginActivityIntent = new Intent(MainActivity.this, LoginActivity.class);
                loginActivityIntent.putExtra("USER_ID", userId);
                loginActivityIntent.putExtra("username", username);
                loginActivityIntent.putExtra("hashedPassword", hashPassword(password));
                startActivity(loginActivityIntent);
            }
        });

        createAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent createAccountIntent = new Intent(MainActivity.this, CreateAccount.class);
                createAccountIntent.putExtra("username", usernameEditText.getText().toString().trim());
                createAccountIntent.putExtra("password", passwordEditText.getText().toString().trim());
                startActivity(createAccountIntent);
            }
        });
    }


    private String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(password.getBytes());
            return Base64.getEncoder().encodeToString(hash);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Failed to hash password", e);
        }
    }
}