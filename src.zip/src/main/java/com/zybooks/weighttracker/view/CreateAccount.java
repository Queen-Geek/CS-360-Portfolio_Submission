package com.zybooks.weighttracker.view;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.zybooks.weighttracker.R;
import com.zybooks.weighttracker.model.WeightTrackerDatabase;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

public class CreateAccount extends AppCompatActivity {

    private EditText usernameEditText, passwordEditText, nameEditText, goalWeightEditText, targetDateEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.create_account); // Make sure this layout has the appropriate EditTexts and Button

        // Initialize UI components
        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        nameEditText = findViewById(R.id.nameEditText);
        goalWeightEditText = findViewById(R.id.goalWeightEditText);
        targetDateEditText = findViewById(R.id.targetDateEditText);
        Button createAccountButton = findViewById(R.id.createAccountButton);

        createAccountButton.setOnClickListener(v -> createAccount());
    }

    private void createAccount() {
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();
        String name = nameEditText.getText().toString().trim();
        String goalWeightStr = goalWeightEditText.getText().toString().trim();
        String targetDate = targetDateEditText.getText().toString().trim();

        if (username.isEmpty() || password.isEmpty() || name.isEmpty() || goalWeightStr.isEmpty() || targetDate.isEmpty()) {
            Toast.makeText(this, "All fields must be filled out.", Toast.LENGTH_SHORT).show();
            return;
        }

        double goalWeight;
        try {
            goalWeight = Double.parseDouble(goalWeightStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Please enter a valid goal weight.", Toast.LENGTH_SHORT).show();
            return;
        }

        String hashedPassword = hashPassword(password);
        WeightTrackerDatabase db = WeightTrackerDatabase.getInstance(this);
        int userId = db.getUserId(username);

        // Ensure this method is implemented to handle not finding the user properly
        if (userId != -1) {
            Toast.makeText(this, "Failed to create account. Please try again.", Toast.LENGTH_LONG).show();

        } else {
            db.addUserProfile(username, hashedPassword, name, goalWeight, targetDate);
            Toast.makeText(this, "Account created successfully!", Toast.LENGTH_LONG).show();
            finish(); // Close this activity and return to the login screen
        }
    }

    // Secure method for hashing passwords
    private String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(password.getBytes());
            return Base64.getEncoder().encodeToString(hash);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Failed to hash password", e);
        }
    }
}