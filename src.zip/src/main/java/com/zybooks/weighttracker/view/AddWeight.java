package com.zybooks.weighttracker.view;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.zybooks.weighttracker.R;
import com.zybooks.weighttracker.model.WeightEntry;
import com.zybooks.weighttracker.model.WeightTrackerDatabase;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AddWeight extends AppCompatActivity {

    private EditText weightEditText;
    private Button saveWeightButton;
    private WeightTrackerDatabase dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_weight);

        weightEditText = findViewById(R.id.weightInput);
        saveWeightButton = findViewById(R.id.saveWeightButton);

        dbHelper = new WeightTrackerDatabase(this);

        saveWeightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveWeight();
            }
        });
    }

    private void saveWeight() {
        String weightStr = weightEditText.getText().toString().trim();
        if (weightStr.isEmpty()) {
            Toast.makeText(this, "Please enter a weight", Toast.LENGTH_SHORT).show();
            return;
        }

        double weight = Double.parseDouble(weightStr);
        String currentDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

        // Assuming you have a method in the database to handle the addition of weight along with current date
        WeightEntry newEntry = new WeightEntry( weight, currentDate); // ID is auto-generated in the database
        dbHelper.addWeight(newEntry);

        Toast.makeText(this, "Weight added successfully on " + currentDate, Toast.LENGTH_LONG).show();
        finish(); // Close this activity and return to the previous one
    }
}