package com.zybooks.weighttracker.view;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.widget.TextView;

import com.zybooks.weighttracker.R;
import com.zybooks.weighttracker.controller.WeightAdapter;
import com.zybooks.weighttracker.model.WeightEntry;
import com.zybooks.weighttracker.model.WeightList;
import com.zybooks.weighttracker.model.WeightTrackerDatabase;

public class HomePage extends AppCompatActivity {
    private RecyclerView weightRecyclerView;
    private WeightTrackerDatabase dbHelper;
    private Button addWeightButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_page);

        dbHelper = new WeightTrackerDatabase(this);
        TextView profileNameTextView = findViewById(R.id.profile_name);
        TextView goalWeightTextView = findViewById(R.id.goal_weight);
        TextView targetDateTextView = findViewById(R.id.target_date);

        weightRecyclerView = findViewById(R.id.weight_recycler_view);
        weightRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        addWeightButton = findViewById(R.id.add_weight_button);
        loadWeights();

        int userId = getIntent().getIntExtra("USER_ID", -1);
        Log.d("HomePage", "Received USER_ID: " + userId); // Log the received userId

        if (userId != -1) {
            WeightTrackerDatabase db = new WeightTrackerDatabase(this);
            Cursor cursor = db.fetchUserProfile(userId);
            if (cursor != null && cursor.moveToFirst()) {
                @SuppressLint("Range") String name = cursor.getString(cursor.getColumnIndex("name"));
                @SuppressLint("Range") double goalWeight = cursor.getDouble(cursor.getColumnIndex("goal_weight"));
                @SuppressLint("Range") String targetDate = cursor.getString(cursor.getColumnIndex("target_date"));

                Log.d("HomePage", "User Profile - Name: " + name + ", Goal Weight: " + goalWeight + ", Target Date: " + targetDate);

                profileNameTextView.setText(name);
                goalWeightTextView.setText(String.valueOf(goalWeight));
                targetDateTextView.setText(targetDate);
                cursor.close();
            } else {
                Log.e("HomePage", "No user profile found for USER_ID: " + userId);
            }
        } else {
            Log.e("HomePage", "Invalid user ID");
        }

        addWeightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HomePage.this, AddWeight.class));
            }
        });

        Button viewWeightButton = findViewById(R.id.view_weights_button);
        viewWeightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HomePage.this, WeightList.class));
            }
        });
    }

    private void loadWeights() {
        java.util.List<WeightEntry> weights = dbHelper.getAllWeights();
        if (weights != null && !weights.isEmpty()) {
            WeightAdapter weightAdapter = new WeightAdapter(weights);
            weightRecyclerView.setAdapter(weightAdapter);
        } else {
            Log.d("HomePage", "No weights found");
            if (addWeightButton != null) {
                addWeightButton.setEnabled(false);
            } else {
                Log.e("HomePage", "addWeightButton is null");
            }
        }
    }
}