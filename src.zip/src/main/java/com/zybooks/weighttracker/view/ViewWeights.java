package com.zybooks.weighttracker.view;

import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.zybooks.weighttracker.R;
import com.zybooks.weighttracker.controller.WeightAdapter;
import com.zybooks.weighttracker.model.WeightEntry;
import com.zybooks.weighttracker.model.WeightTrackerDatabase;

import java.util.List;

public class ViewWeights extends AppCompatActivity {
    private RecyclerView recyclerView;
    private WeightAdapter adapter;
    private WeightTrackerDatabase dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_weights); // Ensure this matches your XML file name

        // Ensure the RecyclerView ID matches the ID in your XML file
        recyclerView = findViewById(R.id.weight_recycler_view); // Adjusted to match the XML file's ID
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        dbHelper = new WeightTrackerDatabase(this);
        loadWeights();
    }

    private void loadWeights() {
        List<WeightEntry> weights = dbHelper.getAllWeights();  // Ensure this method is implemented correctly
        if (weights != null && !weights.isEmpty()) {
            adapter = new WeightAdapter(weights);
            recyclerView.setAdapter(adapter);
        } else {
            // Enhanced handling for no data available
            Toast.makeText(this, "No weight data available.", Toast.LENGTH_LONG).show();
            // Optionally disable features or inform user to add data
        }
    }
}