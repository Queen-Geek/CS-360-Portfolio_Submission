package com.zybooks.weighttracker.view;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.zybooks.weighttracker.R;
import com.zybooks.weighttracker.model.WeightTrackerDatabase;

public class SetGoal extends AppCompatActivity {

    private EditText goalWeightEditText, targetDateEditText;
    private WeightTrackerDatabase dbHelper;

    private String username; // Username passed to this activity
    private String hashedPassword;
    private String name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.set_goal);

        goalWeightEditText = findViewById(R.id.goalWeightEditText);
        targetDateEditText = findViewById(R.id.targetDateEditText);
        Button saveGoalButton = findViewById(R.id.saveGoalButton);

        dbHelper = new WeightTrackerDatabase(this);

        // Retrieve username, password, and name from Intent or session
        username = getIntent().getStringExtra("USERNAME");
        hashedPassword = getIntent().getStringExtra("PASSWORD");
        name = getIntent().getStringExtra("NAME");

        saveGoalButton.setOnClickListener(v -> saveGoal());
    }

    private void saveGoal() {
        double goalWeight;
        try {
            goalWeight = Double.parseDouble(goalWeightEditText.getText().toString().trim());
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Please enter a valid goal weight", Toast.LENGTH_SHORT).show();
            return;
        }

        String targetDate = targetDateEditText.getText().toString().trim();

        if (targetDate.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        int userId = dbHelper.getUserId(username); // Fetch the current user's ID
        if (userId == -1) {
            Toast.makeText(this, "User not found", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean result = dbHelper.addUserProfile(username, hashedPassword, name, goalWeight, targetDate);
        if(result) {
            Toast.makeText(this, "Goal saved successfully!", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Failed to save goal", Toast.LENGTH_SHORT).show();
        }
    }
}